import aiosqlite
import logging
from typing import List, Dict, Optional
from config import MAX_HISTORY_MESSAGES, DEFAULT_MODEL

logger = logging.getLogger(__name__)

class DatabaseManager:
    def __init__(self, db_path: str = "bot_database.db"):
        self.db_path = db_path

    async def init_db(self):
        """Initialize the database tables."""
        try:
            async with aiosqlite.connect(self.db_path) as db:
                # Create chats table
                await db.execute("""
                    CREATE TABLE IF NOT EXISTS chats (
                        chat_id INTEGER PRIMARY KEY,
                        custom_role TEXT,
                        custom_goal TEXT,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                """)
                
                # Try to add columns if they don't exist (Migration)
                try:
                    await db.execute("ALTER TABLE chats ADD COLUMN timeout_seconds INTEGER DEFAULT NULL")
                except aiosqlite.OperationalError:
                    pass

                try:
                    await db.execute("ALTER TABLE chats ADD COLUMN model TEXT DEFAULT NULL")
                except aiosqlite.OperationalError:
                    pass

                try:
                    await db.execute("ALTER TABLE chats ADD COLUMN is_active INTEGER DEFAULT 0")
                except aiosqlite.OperationalError:
                    pass
                
                # Create messages table
                await db.execute("""
                    CREATE TABLE IF NOT EXISTS messages (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        chat_id INTEGER,
                        role TEXT,
                        content TEXT,
                        timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        FOREIGN KEY (chat_id) REFERENCES chats (chat_id)
                    )
                """)
                
                await db.commit()
                logger.info("Database initialized successfully.")
                
            # Perform cleanup on startup
            await self.cleanup_old_messages()
            
        except Exception as e:
            logger.error(f"Error initializing database: {e}")

    async def get_chat_settings(self, chat_id: int) -> Dict[str, any]:
        """Retrieve settings for a chat."""
        try:
            async with aiosqlite.connect(self.db_path) as db:
                async with db.execute("SELECT custom_role, custom_goal, timeout_seconds, model, is_active FROM chats WHERE chat_id = ?", (chat_id,)) as cursor:
                    row = await cursor.fetchone()
                    if row:
                        model = row[3] if row[3] else DEFAULT_MODEL
                        is_active = bool(row[4])
                        return {
                            "custom_role": row[0],
                            "custom_goal": row[1],
                            "timeout_seconds": row[2],
                            "model": model,
                            "is_active": is_active
                        }
                    return {
                        "custom_role": "",
                        "custom_goal": "",
                        "timeout_seconds": None,
                        "model": DEFAULT_MODEL,
                        "is_active": False
                    }
        except Exception as e:
            logger.error(f"Error getting chat settings for {chat_id}: {e}")
            return {"custom_role": "", "custom_goal": "", "timeout_seconds": None, "model": DEFAULT_MODEL, "is_active": False}

    async def update_chat_settings(self, chat_id: int, custom_role: Optional[str] = None, custom_goal: Optional[str] = None, timeout_seconds: Optional[int] = None, model: Optional[str] = None, is_active: Optional[bool] = None):
        """Update or insert chat settings."""
        try:
            async with aiosqlite.connect(self.db_path) as db:
                # Check if chat exists
                async with db.execute("SELECT 1 FROM chats WHERE chat_id = ?", (chat_id,)) as cursor:
                    exists = await cursor.fetchone()
                
                if exists:
                    if custom_role is not None:
                        await db.execute("UPDATE chats SET custom_role = ? WHERE chat_id = ?", (custom_role, chat_id))
                    if custom_goal is not None:
                        await db.execute("UPDATE chats SET custom_goal = ? WHERE chat_id = ?", (custom_goal, chat_id))
                    if timeout_seconds is not None:
                        await db.execute("UPDATE chats SET timeout_seconds = ? WHERE chat_id = ?", (timeout_seconds, chat_id))
                    if model is not None:
                        await db.execute("UPDATE chats SET model = ? WHERE chat_id = ?", (model, chat_id))
                    if is_active is not None:
                         val = 1 if is_active else 0
                         await db.execute("UPDATE chats SET is_active = ? WHERE chat_id = ?", (val, chat_id))

                else:
                    role = custom_role if custom_role is not None else ""
                    goal = custom_goal if custom_goal is not None else ""
                    timeout = timeout_seconds if timeout_seconds is not None else None
                    mod = model if model is not None else DEFAULT_MODEL
                    active_val = 1 if is_active else 0
                    
                    await db.execute(
                        "INSERT INTO chats (chat_id, custom_role, custom_goal, timeout_seconds, model, is_active) VALUES (?, ?, ?, ?, ?, ?)", 
                        (chat_id, role, goal, timeout, mod, active_val)
                    )
                
                await db.commit()
                logger.info(f"Updated settings for chat {chat_id}")
        except Exception as e:
            logger.error(f"Error updating chat settings for {chat_id}: {e}")

    async def get_active_chats(self) -> List[int]:
        """Retrieve all active chat IDs."""
        try:
            async with aiosqlite.connect(self.db_path) as db:
                async with db.execute("SELECT chat_id FROM chats WHERE is_active = 1") as cursor:
                    rows = await cursor.fetchall()
                    return [row[0] for row in rows]
        except Exception as e:
            logger.error(f"Error getting active chats: {e}")
            return []

    async def add_message(self, chat_id: int, role: str, content: str):
        """Add a message to the history."""
        try:
            async with aiosqlite.connect(self.db_path) as db:
                await db.execute("INSERT INTO messages (chat_id, role, content) VALUES (?, ?, ?)", (chat_id, role, content))
                await db.commit()
        except Exception as e:
            logger.error(f"Error adding message for chat {chat_id}: {e}")

    async def get_chat_history(self, chat_id: int, limit: int = 20) -> List[Dict[str, str]]:
        """Retrieve the last N messages for a chat."""
        try:
            async with aiosqlite.connect(self.db_path) as db:
                # Get last N messages
                async with db.execute("""
                    SELECT role, content FROM (
                        SELECT role, content, timestamp 
                        FROM messages 
                        WHERE chat_id = ? 
                        ORDER BY timestamp DESC 
                        LIMIT ?
                    ) ORDER BY timestamp ASC
                """, (chat_id, limit)) as cursor:
                    rows = await cursor.fetchall()
                    return [{"role": row[0], "content": row[1]} for row in rows]
        except Exception as e:
            logger.error(f"Error getting history for chat {chat_id}: {e}")
            return []

    async def clear_history(self, chat_id: int):
        """Clear message history for a chat."""
        try:
            async with aiosqlite.connect(self.db_path) as db:
                await db.execute("DELETE FROM messages WHERE chat_id = ?", (chat_id,))
                await db.commit()
                logger.info(f"Cleared history for chat {chat_id}")
        except Exception as e:
            logger.error(f"Error clearing history for chat {chat_id}: {e}")

    async def cleanup_old_messages(self, limit: int = MAX_HISTORY_MESSAGES):
        """Delete messages exceeding the limit for each chat."""
        try:
            async with aiosqlite.connect(self.db_path) as db:
                # Get all chat_ids that have messages
                async with db.execute("SELECT DISTINCT chat_id FROM messages") as cursor:
                    rows = await cursor.fetchall()
                    chat_ids = [row[0] for row in rows]
                
                deleted_count = 0
                for chat_id in chat_ids:
                    # SQLite delete logic with subquery
                    await db.execute("""
                        DELETE FROM messages 
                        WHERE chat_id = ? AND id NOT IN (
                            SELECT id FROM messages 
                            WHERE chat_id = ? 
                            ORDER BY timestamp DESC, id DESC 
                            LIMIT ?
                        )
                    """, (chat_id, chat_id, limit))
                    # Note: aiosqlite cursor.rowcount might not be immediately available after execute on connection shorthand
                    # But that's okay for logging purposes
                
                await db.commit()
                logger.info(f"Cleanup finished.")
                    
        except Exception as e:
            logger.error(f"Error cleaning up old messages: {e}")
